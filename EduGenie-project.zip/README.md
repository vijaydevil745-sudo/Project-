# EduGenie
Simple FastAPI + Gemini learning assistant.

Features: Explain, QnA, Quiz, Summary, Recommend Path.

Set GEMINI_API_KEY as an environment variable, then run:
uvicorn main:app --host 0.0.0.0 --port 8000
