import os
from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
import google.generativeai as genai

app = FastAPI(title='EduGenie')
templates = Jinja2Templates(directory='templates')
API_KEY = os.getenv('GEMINI_API_KEY')
if API_KEY: genai.configure(api_key=API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

def ask_gemini(prompt):
    if not API_KEY: return 'Please set GEMINI_API_KEY before using EduGenie.'
    return model.generate_content(prompt).text

@app.get('/', response_class=HTMLResponse)
async def home(request: Request): return templates.TemplateResponse('index.html', {'request':request,'result':''})

@app.post('/ask', response_class=HTMLResponse)
async def ask(request: Request, mode: str=Form(...), text: str=Form(...)):
    prompts={'Explain':f'Explain this concept simply for a student: {text}','QnA':f'Answer this student question clearly and concisely: {text}','Quiz':f'Create 5 multiple-choice quiz questions with answers about: {text}','Summary':f'Summarize the following educational text in simple points: {text}','Recommend Path':f'Create a structured learning path for a student who wants to learn: {text}. Include topics and a simple sequence.'}
    result=ask_gemini(prompts.get(mode,prompts['QnA']))
    return templates.TemplateResponse('index.html', {'request':request,'result':result})

@app.get('/health')
async def health(): return {'status':'ok'}
